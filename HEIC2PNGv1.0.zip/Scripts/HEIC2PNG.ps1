﻿$sourceFolder = "C:\Images"
$destinationFolder = "C:\Images\PNGs"
$counter = 1

# Get a list of .HEIC files in the source folder
$heicFiles = Get-ChildItem -Path $sourceFolder -Filter "*.HEIC"

foreach ($file in $heicFiles) {
    $baseName = $file.BaseName
    $destinationFile = Join-Path $destinationFolder ($counter.ToString() + ".png")

    # Convert HEIC to PNG and resize by 25% using ImageMagick
    & "C:\Images\Image-Magick\convert.exe" $file.FullName -resize 25% $destinationFile

    # Increment the counter for the next file
    $counter++

    Write-Host "Converted and saved $($file.Name) as $($destinationFile)"
}

# Verification and cleanup
$convertedFiles = Get-ChildItem -Path $destinationFolder -Filter "*.png"
if ($convertedFiles.Count -eq $heicFiles.Count) {
    Write-Host "All files converted and renamed successfully."
    
    # Delete original .HEIC files
    foreach ($heicFile in $heicFiles) {
        Remove-Item $heicFile.FullName -Force
        Write-Host "Deleted $($heicFile.Name)"
    }
} else {
    Write-Host "Conversion or renaming may not be complete. Manual verification needed."
}
