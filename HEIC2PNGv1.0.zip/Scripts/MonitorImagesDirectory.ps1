﻿$downloadsPath = "C:\Images"
$copyImagesScriptPath = "C:\Scripts\HEIC2PNG.ps1"
$waitTimeInSeconds = 5

function Start-MonitorDownloads {
    $lastChangeTime = $null

    while ($true) {
        $currentChangeTime = (Get-ChildItem $downloadsPath -Recurse | Measure-Object -Property LastWriteTime -Maximum).Maximum

        if ($lastChangeTime -and $currentChangeTime -eq $lastChangeTime) {
            $elapsedTime = (Get-Date) - $currentChangeTime
            if ($elapsedTime.TotalSeconds -ge $waitTimeInSeconds) {
                $filesInDownloads = Get-ChildItem $downloadsPath -File -Recurse
                if ($filesInDownloads.Count -gt 0) {
                    Write-Host "Running HEIC2PNG.ps1..."
                    & $copyImagesScriptPath
                }
            }
        } else {
            $lastChangeTime = $currentChangeTime
        }

        Start-Sleep -Seconds 5
    }
}

function Wait-ForFileNotInUse {
    param (
        [string]$filePath,
        [int]$waitTimeInSeconds
    )

    while ($true) {
        try {
            $fileStream = [System.IO.File]::Open($filePath, 'Open', 'Read')
            $fileStream.Close()
            break  # File is not in use, break out of the loop
        } catch {
            Write-Host "File '$filePath' is in use. Waiting $waitTimeInSeconds seconds..."
            Start-Sleep -Seconds $waitTimeInSeconds
        }
    }
}

Start-MonitorDownloads
